# 🚀 Brown- Free DDoS Panel 🚀
> Your terminal has to accept ANSI colors so that the colors can be seen<br>
> Username: 1337<br>
> Password: 1337<br>

proxy update command proxy-crawl
telegram: mertsoyan


# Tree
* [Read this Pls](#plz-%EF%B8%8F)
* [Brown Info](Brown-Info)
* [Setup](#Setup)
* [Credits](#Credits)
* [T.O.S](#TOS)

# Plz ♥️
It would help me a lot if you give a star ⭐ to this repository.<br>
One star from you = more desire to continue updating Brown

# BrownC2 Info
- [x] Open Source
- [x] Stable
- [x] Simple
- [x] Methods for Layer 4 and 7
- [x] Bypass (CF, OVH, Etc)  
- The source is not mine, I just made a few additions, the original owner of the source SkyWtkh

# Setup
```sh
git clone https://github.com/rude1882/brownc2
cd Stanley
sudo python3 installer.py
ulimit -n 999999
chmod +x *
sudo python3 brown.py
```

# Credits
```sh
CNC Coded SkyWtkh
MHProDev
Empfaked
im-federal
R00tS3C
(Methods <3)
Z3NTL3
(Inspiration <3)
```

# TOS:
```sh
Do not attack government pages (.gov/.gob), educational pages (.edu) or the United States Department of Defense (.mil), 
the creator is not responsible for the damage caused by the attacks. 
remember: you are responsible for the attacks since this tool was created for educational purposes
```
